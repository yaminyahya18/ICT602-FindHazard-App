# ICT602PROJECT
 A mobile application that implements concept of crowdsourcing information. Application will display news, display map of known hazards on map. The map markers will display type of hazard, time and date the hazarded reported and who reported the hazards.
